//
//  CellVariantController.swift
//  CovidTable
//
//  Created by Usuario invitado on 17/1/22.
//  Copyright © 2022 Usuario invitado. All rights reserved.
//

import Foundation
import UIKit

class CellVariantController: UITableViewCell {
    @IBOutlet weak var lblLineage: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblDesignated: UILabel!
    @IBOutlet weak var lblAssigned: UILabel!
    @IBOutlet weak var lblName: UILabel!
    
}
